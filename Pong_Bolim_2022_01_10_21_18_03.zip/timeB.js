// TIME B (AZUL)

let xTimeB = [400, 75]
// ATACANTE TIME B

let yTimeB = 150;
let larguraTimeB = 15;
let alturaTimeB = 70; 


function timeB(){
  fill(color('#B0E0E6'))
  strokeWeight(0)
  rect (xTimeB [0], yTimeB, larguraTimeB, alturaTimeB)
  rect (xTimeB[1], yTimeB,larguraTimeB, alturaTimeB)
}

function movimentaTimeB() {
 if (keyIsDown(83)) {
        yTimeB+= 10;
    }
    if (keyIsDown(87)) {
        yTimeB-= 10;  
    }
    }
