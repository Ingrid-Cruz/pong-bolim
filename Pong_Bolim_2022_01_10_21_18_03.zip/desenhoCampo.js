function desenhoCampo(){
  stroke('white');
  fill(color('white'))
  //CIRCULOS
  circle(75, 200, 5)
  circle(525, 200, 5)
  circle(300, 200, 5)
 
  strokeWeight(2);
  noFill();
  //MEIO DE CAMPO
  rect(8, 8, 584, 384)
  line(300,8,300, 392)
  circle(300, 200, 150)
  rect(8, 96, 100, 192)
  rect(492, 96, 100, 192)
  rect(542, 130, 50, 120)
  rect(8, 130, 50, 120)
  // ARCOS ESCANTEIO
  angleMode(DEGREES)
  arc(490, height / 2, 40, 90, 90, -90);
  arc( 110, height / 2, 40, 90, -90, 90);
  arc( 10, 10, 30, 30, 0, 90);
  arc( 590, 10, 30, 30, -270, 180);
  arc( 590, 390, 30, 30, 180, 270);
  arc( 10, 390, 30, 30, -90, 0);
  }
  

