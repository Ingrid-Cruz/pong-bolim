// VARIAVEIS BOLA DE CAMPO

let xBola = 300;
let yBola = 200;
let diametro = 20;
let raio = diametro / 2
let velocidadeXBola = 5
let velocidadeYBola = 5

let colidiu = false;

function boladeCampo(){
  strokeWeight(0)
  fill(color('white'))
  circle(xBola, yBola, diametro)}

// MOVIMENTA BOLA
function movimentaBola(){
  xBola = xBola + velocidadeXBola
  yBola = yBola + velocidadeYBola
}

// COLISÃO BORDA

function colisaoBolaBorda(){
  if (xBola + raio > width || xBola - raio < 0){
    velocidadeXBola *= -1;
  }
   if (yBola + raio > height || yBola - raio < 0){
    velocidadeYBola *= -1;
  }
}

// COLISAO JOGADORES A

function verificaColisaoTimeA(){
  colidiu =
  collideRectCircle(xTimeA[0], ytimeA, larguraTimeA, alturaTimeA,xBola, yBola, raio) || collideRectCircle(xTimeA[1], ytimeA, larguraTimeA, alturaTimeA,xBola, yBola, raio)
  if (colidiu){
    velocidadeXBola *= -1;
    chute.play();
  }
}

// COLISÕES JOGADORES B
function verificaColisaoTimeB(){
  colidiu =
 collideRectCircle(xTimeB[0], yTimeB, larguraTimeB, alturaTimeB,xBola, yBola, raio) || collideRectCircle(xTimeB[1], yTimeB, larguraTimeB, alturaTimeB,xBola, yBola, raio)
 if (colidiu){
   velocidadeXBola *= -1;
   chute.play();
} }
