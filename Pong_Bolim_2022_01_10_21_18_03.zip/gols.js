// GOLS
let xGol1= 1
let yGol1= 140
let largura1= 5
let altura1 = 100
///////////
let xGol2 = 594
function mostragols(){
  fill(color('white'))
  strokeWeight(0)
  rect(xGol1, yGol1, largura1, altura1)
  rect(xGol2, yGol1, largura1, altura1)
}