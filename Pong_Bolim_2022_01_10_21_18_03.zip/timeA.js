// TIME A (ROSA)

let xTimeA = [190, 500]
let ytimeA = 150;
let larguraTimeA=15
let alturaTimeA =70;

function timeA(){
  fill(color('#FFDAB9'))
  strokeWeight(0)
  rect (xTimeA[0], ytimeA, larguraTimeA, alturaTimeA)
  rect (xTimeA[1], ytimeA, larguraTimeA, alturaTimeA)
}
function movimentaTimeA() {
    if (keyIsDown(UP_ARROW)) {
        ytimeA-= 10;
       
    }
    if (keyIsDown(DOWN_ARROW)) {
       ytimeA+= 10;
    }
    }
