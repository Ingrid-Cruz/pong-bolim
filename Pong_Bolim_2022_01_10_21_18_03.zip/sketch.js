
function setup() {
  createCanvas(600, 400);
  torcida.loop();
}

function draw() {
  background('green');
  
  boladeCampo();
  timeB();
  timeA();
  movimentaBola();
  movimentaTimeA();
  movimentaTimeB();
  colisaoBolaBorda();
  verificaColisaoTimeA();
  verificaColisaoTimeB();
  mostragols();
  placar();
  desenhoCampo();}

