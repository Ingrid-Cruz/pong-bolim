// PLACAR DO JOGO

let meuspontos = 0
let pontosoutrotime = 0

// MARCAÇÃO DE PONTOS 
function placar(){
  strokeWeight(0)
  textSize(17)
  fill(color('#FFDAB9'))
  stroke(0)
  rect(430, 10, 40, 20)
  fill(color('#B0E0E6'))
  rect(130, 10, 40, 20)
  fill(color('#008080'))
  text(meuspontos, 445, 26)
  text(pontosoutrotime, 145, 26)
  
  colidiu =
 collideRectCircle(xGol1, yGol1, largura1, altura1,xBola, yBola, raio) 
 if (colidiu){
   meuspontos += 1
   pontos.play();
   xBola = 300
   yBola = 200 }

  colidiu =
 collideRectCircle(xGol2, yGol1, largura1, altura1,xBola, yBola, raio)
 if (colidiu){
   pontosoutrotime += 1
   pontos.play();
   xBola = 300
   yBola = 200 }
}