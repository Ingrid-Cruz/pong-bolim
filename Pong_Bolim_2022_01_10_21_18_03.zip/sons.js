// SONS DO JOGO
let chute;
let trilha;
let pontos;

function preload(){
  torcida = loadSound("torcida.mp3")
  chute = loadSound("raquetada.mp3")
  pontos = loadSound("ponto.mp3")
}

